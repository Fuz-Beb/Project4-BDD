package Bibliotheque;

import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * Gestion des transactions de reliées à la création et suppresion de livres
 * dans une bibliothèque.
 *
 * <pre>
 * Vincent Ducharme
 * Université de Sherbrooke
 * Version 1.0 - 18 juin 2016
 * IFT287 - Exploitation de BD relationnelles et OO
 *
 * Ce programme permet de gérer les transaction reliées à la 
 * création et suppresion de livres.
 *
 * Pré-condition
 *   La base de données de la bibliothèque doit exister
 *
 * Post-condition
 *   Le programme effectue les maj associées à chaque
 *   transaction
 * </pre>
 */
public class GestionLivre
{
    private Livres livres;
    private Reservations reservations;
    private Connexion cx;

    /**
     * Creation d'une instance
     */
    public GestionLivre(Livres livres, Reservations reservations) throws BiblioException
    {
        this.cx = livres.getConnexion();
        if (livres.getConnexion() != reservations.getConnexion())
            throw new BiblioException("Les collections d'objets n'utilisent pas la même connexion au serveur");
        this.livres = livres;
        this.reservations = reservations;
    }

    /**
     * Ajout d'un nouveau livre dans la base de données. S'il existe déjà, une
     * exception est levée.
     */
    public void acquerir(int idLivre, String titre, String auteur, Date dateAcquisition)
            throws BiblioException, Exception
    {
        try
        {
            cx.demarreTransaction();

            Livre livre = new Livre(idLivre, titre, auteur, dateAcquisition);
            // Vérifie si le livre existe déja
            if (livres.existe(idLivre))
                throw new BiblioException("Livre existe déjà: " + idLivre);

            // Ajout du livre dans la table des livres
            livres.acquerir(livre);
            cx.commit();
        }
        catch (Exception e)
        {
            cx.rollback();
            throw e;
        }
    }

    /**
     * Vente d'un livre.
     */
    public void vendre(int idLivre) throws BiblioException, Exception
    {
        try
        {
            cx.demarreTransaction();

            Livre livre = livres.getLivre(idLivre);
            if (livre == null)
                throw new BiblioException("Livre inexistant: " + idLivre);
            if (livre.getEmprunteur() != null)
                throw new BiblioException("Livre " + idLivre + " prêté à " + livre.getEmprunteur().getNom());
            if (reservations.getReservationLivre(livre) != null)
                throw new BiblioException("Livre " + idLivre + " réservé ");

            // Suppression du livre.
            if (!livres.vendre(livre))
                throw new BiblioException("Livre " + idLivre + " inexistant");

            cx.commit();
        }
        catch (Exception e)
        {
            cx.rollback();
            throw e;
        }
    }

    /**
     * Affiche les livres prêtés depuis plus de 14 jours.
     */
    public void listerLivresRetard(Date date)
    {
        cx.demarreTransaction();

        List<Livre> l = livres.calculerLivres();
        GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        calendar.add(GregorianCalendar.DATE, -14);
        for (Livre li : l)
        {
            if (li.getEmprunteur() != null)
            {
                if (li.getDatePret().before(calendar.getTime()))
                {
                    System.out.println(li.toString());
                }
            }
        }

        cx.commit();
    }
    
    /**
     * Affiche les livres contenu un mot dans le titre
     */
    public void listerLivresTitre(String mot)
    {
        cx.demarreTransaction();
        
        List<Livre> l = livres.calculerLivresTitre(mot);

        for(Livre li : l)
        {
            System.out.println(li.toString());
        }
        
        cx.commit();
    }
    
    /**
     * Affiche tous les livres de la BD
     */
    public void listerLivres()
    {
        cx.demarreTransaction();
        
        List<Livre> l = livres.calculerLivres();
                
        for(Livre li : l)
        {
            System.out.println(li.toString());
        }
        
        cx.commit();
    }
}
