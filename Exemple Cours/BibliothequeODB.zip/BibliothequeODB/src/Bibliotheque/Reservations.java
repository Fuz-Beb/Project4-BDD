package Bibliotheque;

import java.util.List;

import javax.persistence.TypedQuery;

/**
 * Permet d'effectuer les accès à la collections des réservations.
 * 
 * <pre>
 *
 * Vincent Ducharme
 * Université de Sherbrooke
 * Version 1.0 - 18 juin 2016
 * IFT287 - Exploitation de BD relationnelles et OO
 * 
 * Cette classe gère tous les accès à la collection des réservations.
 *
 * </pre>
 */

public class Reservations
{
    private TypedQuery<Reservation> stmtExiste;
    private TypedQuery<Reservation> stmtExisteLivre;
    private TypedQuery<Reservation> stmtExisteMembre;
    private Connexion cx;

    /**
     * Creation d'une instance.
     */
    public Reservations(Connexion cx)
    {
        this.cx = cx;
        stmtExiste = cx.getConnection().createQuery("select r from Reservation r where r.m_idReservation = :idReservation", Reservation.class);
        stmtExisteLivre = cx.getConnection().createQuery("select r from Reservation r where r.m_livre = :livre order by r.m_dateReservation", Reservation.class);
        stmtExisteMembre = cx.getConnection().createQuery("select r from Reservation r where r.m_membre = :membre", Reservation.class);
    }

    /**
     * Retourner la connexion associée.
     */
    public Connexion getConnexion()
    {
        return cx;
    }

    /**
     * Verifie si une reservation existe.
     */
    public boolean existe(int idReservation)
    {
        stmtExiste.setParameter("idReservation", idReservation);
        return !stmtExiste.getResultList().isEmpty();
    }

    /**
     * Lecture d'une reservation.
     */
    public Reservation getReservation(int idReservation)
    {
        stmtExiste.setParameter("idReservation", idReservation);
        List<Reservation> reservations = stmtExiste.getResultList();
        if(!reservations.isEmpty())
        {
            return reservations.get(0);
        }
        return null;
    }

    /**
     * Lecture de la première reservation d'un livre.
     */
    public Reservation getReservationLivre(Livre livre)
    {
        stmtExisteLivre.setParameter("livre", livre);
        List<Reservation> reservations = stmtExisteLivre.getResultList();
        if(!reservations.isEmpty())
        {
            return reservations.get(0);
        }
        return null;
    }

    /**
     * Lecture de la première reservation d'un livre.
     */
    public Reservation getReservationMembre(Membre membre)
    {
        stmtExisteMembre.setParameter("membre", membre);
        List<Reservation> reservations = stmtExisteMembre.getResultList();
        if(!reservations.isEmpty())
        {
            return reservations.get(0);
        }
        return null;
    }

    /**
     * Réservation d'un livre.
     */
    public void reserver(Reservation r)
    {
        cx.getConnection().persist(r);
    }

    /**
     * Suppression d'une reservation.
     */
    public boolean annulerRes(Reservation r)
    {
        if(r != null)
        {
            cx.getConnection().remove(r);
            return true;
        }
        return false;
    }
}
