package Bibliotheque;

import java.util.Date;

import javax.persistence.*;

/**
 * Permet de représenter une réservation.
 * 
 * <pre>
 * Vincent Ducharme
 * Université de Sherbrooke
 * Version 1.0 - 18 juin 2016
 * IFT287 - Exploitation de BD relationnelles et OO
 *
 * </pre>
 */

@Entity
public class Reservation
{
    @Id
    @GeneratedValue
    private long m_id;
    
    private int m_idReservation;
    private Livre m_livre;
    private Membre m_membre;
    private Date m_dateReservation;
    
    public Reservation()
    {
    }

    public Reservation(int idReservation, Membre m, Livre l, Date dateReservation)
    {
        m_idReservation = idReservation;
        m_membre = m;
        m_livre = l;
        m_dateReservation = dateReservation;
    }
    
    public long getId()
    {
        return m_id;
    }
    
    public int getIdReservation()
    {
        return m_idReservation;
    }

    public Membre getMembre()
    {
        return m_membre;
    }

    public Livre getLivre()
    {
        return m_livre;
    }

    public Date getDateReservation()
    {
        return m_dateReservation;
    }
}
