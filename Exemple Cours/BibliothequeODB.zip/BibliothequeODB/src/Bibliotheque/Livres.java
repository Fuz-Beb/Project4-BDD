package Bibliotheque;

import java.util.*;

import javax.persistence.TypedQuery;

/**
 * Permet d'effectuer les accès à la collection des Livres.
 * 
 * <pre>
 * 
 * Vincent Ducharme
 * Université de Sherbrooke
 * Version 1.0 - 18 juin 2016
 * IFT287 - Exploitation de BD relationnelles et OO
 * 
 * Cette classe gère tous les accès à la collection des Livres.
 * 
 * </pre>
 */

public class Livres
{
    private Connexion cx;
    private TypedQuery<Livre> stmtExiste;
    private TypedQuery<Livre> stmtListePret;
    private TypedQuery<Livre> stmtLivresTitreMot;
    private TypedQuery<Livre> stmtListeTousLivres;
    

    /**
     * Creation d'une instance.
     */
    public Livres(Connexion cx)
    {
        this.cx = cx;
        stmtExiste = cx.getConnection().createQuery("select l from Livre l where l.m_idLivre = :idLivre", Livre.class);
        
        stmtListePret = cx.getConnection().createQuery("select l from Livre l where l.m_membre = :membre", Livre.class);
        
        stmtListeTousLivres = cx.getConnection().createQuery("select l from Livre l", Livre.class);
        
        stmtLivresTitreMot = cx.getConnection().createQuery("select l from Livre l where lower(l.m_titre) like :titre", Livre.class);
    }

    /**
     * Retourner la connexion associée.
     */
    public Connexion getConnexion()
    {
        return cx;
    }

    /**
     * Verifie si un livre existe.
     */
    public boolean existe(int idLivre)
    {        
        stmtExiste.setParameter("idLivre", idLivre);
        return !stmtExiste.getResultList().isEmpty();
    }

    /**
     * Lecture d'un livre.
     */
    public Livre getLivre(int idLivre)
    {
        stmtExiste.setParameter("idLivre", idLivre);
        List<Livre> livres = stmtExiste.getResultList();
        if(!livres.isEmpty())
        {
            return livres.get(0);
        }
        else
        {
            return null;
        }
    }

    /**
     * Ajout d'un nouveau livre dans la base de donnees.
     */
    public Livre acquerir(Livre livre)
    {
        // Ajout du livre.
        cx.getConnection().persist(livre);
        
        return livre;
    }

    /**
     * Suppression d'un livre.
     */
    public boolean vendre(Livre livre)
    {
        if(livre != null)
        {
            cx.getConnection().remove(livre);
            return true;
        }
        return false;
    }

    public List<Livre> calculerListePret(Membre m)
    {
        // À noter qu'une meilleure façon serait d'avoir une méthode getPrets dans 
        // la classe Membre qui retourne directement la liste des prêts.
        stmtListePret.setParameter("membre", m);
        return stmtListePret.getResultList();
    }
    
    public List<Livre> calculerLivres()
    {
        List<Livre> livres = stmtListeTousLivres.getResultList();
        return livres;
    }
    
    public List<Livre> calculerLivresTitre(String mot)
    {
        stmtLivresTitreMot.setParameter("titre", "%" + mot + "%");
        List<Livre> livres = stmtLivresTitreMot.getResultList();
        return livres;
    }
}
