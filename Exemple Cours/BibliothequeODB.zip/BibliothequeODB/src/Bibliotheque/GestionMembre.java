package Bibliotheque;

/**
 * Gestion des transactions de reliées à la création et suppresion de membres
 * dans une bibliothèque.
 *
 * <pre>
 * Vincent Ducharme
 * Université de Sherbrooke
 * Version 1.0 - 18 juin 2016
 * IFT287 - Exploitation de BD relationnelles et OO
 *
 * Ce programme permet de gérer les transaction reliées à la 
 * création et suppresion de membres.
 *
 * Pré-condition
 *   La base de données de la bibliothèque doit exister
 *
 * Post-condition
 *   Le programme effectue les maj associées à chaque
 *   transaction
 * </pre>
 */

public class GestionMembre
{
    private Connexion cx;
    private Membres membres;
    private Reservations reservations;

    /**
     * Creation d'une instance
     */
    public GestionMembre(Membres membres, Reservations reservations) throws BiblioException
    {
        this.cx = membres.getConnexion();
        if (membres.getConnexion() != reservations.getConnexion())
            throw new BiblioException("Les collections d'objets n'utilisent pas la même connexion au serveur");
        this.membres = membres;
        this.reservations = reservations;
    }

    /**
     * Ajout d'un nouveau membre dans la base de données. S'il existe déjà, une
     * exception est levée.
     */
    public void inscrire(int idMembre, String nom, long telephone, int limitePret)
            throws BiblioException, Exception
    {
        try
        {
            cx.demarreTransaction();
            
            Membre m = new Membre(idMembre, nom, telephone, limitePret);
            
            // Vérifie si le membre existe déja
            if (membres.existe(idMembre))
                throw new BiblioException("Membre existe déjà: " + idMembre);

            // Ajout du membre.
            membres.inscrire(m);
            cx.commit();
        }
        catch (Exception e)
        {
            cx.rollback();
            throw e;
        }
    }

    /**
     * Suppression d'un membre de la base de données.
     */
    public void desinscrire(int idMembre) throws BiblioException, Exception
    {
        try
        {
            cx.demarreTransaction();
            
            // Vérifie si le membre existe et son nombre de pret en cours
            Membre membre = membres.getMembre(idMembre);
            if (membre == null)
                throw new BiblioException("Membre inexistant: " + idMembre);
            if (membre.getNbPret() > 0)
                throw new BiblioException("Le membre " + idMembre + " a encore des prêts.");
            if (reservations.getReservationMembre(membre) != null)
                throw new BiblioException("Membre " + idMembre + " a des réservations");

            // Suppression du membre
            if(!membres.desinscrire(membre))
                throw new BiblioException("Membre " + idMembre + " inexistant");
            
            cx.commit();
        }
        catch (Exception e)
        {
            cx.rollback();
            throw e;
        }
    }
}// class
