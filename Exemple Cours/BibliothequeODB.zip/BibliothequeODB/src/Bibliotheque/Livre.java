package Bibliotheque;

import java.util.Date;

import javax.persistence.*;

/**
 * Permet de représenter un livre.
 * 
 * <pre>
 * Vincent Ducharme
 * Université de Sherbrooke
 * Version 1.0 - 18 juin 2016
 * IFT287 - Exploitation de BD relationnelles et OO
 * 
 * </pre>
 */

@Entity
public class Livre
{
    @Id
    @GeneratedValue
    private long m_id;

    private int m_idLivre;
    private String m_titre;
    private String m_auteur;
    private Date m_dateAcquisition;
    @ManyToOne(fetch = FetchType.LAZY)
    private Membre m_membre;
    private Date m_datePret;

    public Livre()
    {
    }

    public Livre(int idLivre, String titre, String auteur, Date dateAcquisition)
    {
        m_idLivre = idLivre;
        m_titre = titre;
        m_auteur = auteur;
        m_dateAcquisition = dateAcquisition;
        m_membre = null;
        m_datePret = null;
    }

    public long getID()
    {
        return m_id;
    }
    
    public int getIdLivre()
    {
        return m_idLivre;
    }

    public String getTitre()
    {
        return m_titre;
    }

    public String getAuteur()
    {
        return m_auteur;
    }

    public Date getDateAcquisition()
    {
        return m_dateAcquisition;
    }

    public void preter(Membre m, Date datePret)
    {
        m_membre = m;
        m_datePret = datePret;
    }

    public Membre getEmprunteur()
    {
        return m_membre;
    }

    public Date getDatePret()
    {
        return m_datePret;
    }

    public void retourner()
    {
        m_membre = null;
        m_datePret = null;
    }

    public String toString()
    {
        StringBuffer s = new StringBuffer(getTitre() + " " + getAuteur() + " " + getDateAcquisition());
        if (getEmprunteur() != null)
            s.append(" prete a " + getEmprunteur().getNom() + " " + getDatePret());
        return s.toString();
    }
}
