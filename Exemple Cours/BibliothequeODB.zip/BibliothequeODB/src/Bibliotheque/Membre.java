package Bibliotheque;

import java.util.LinkedList;
import java.util.List;

import javax.persistence.*;

/**
 * Permet de représenter un membre.
 * 
 * <pre>
 * Vincent Ducharme
 * Université de Sherbrooke
 * Version 1.0 - 18 juin 2016
 * IFT287 - Exploitation de BD relationnelles et OO
 *
 * </pre>
 */

@Entity
public class Membre
{
    @Id
    @GeneratedValue
    private long m_id;

    private int m_idMembre;
    private String m_nom;
    private long m_telephone;
    private int m_limitePret;
    
    @OneToMany(mappedBy = "m_membre")
    @OrderBy("m_datePret")
    private List<Livre> m_emprunt;

    public Membre()
    {
    }

    public Membre(int idMembre, String nom, long telephone, int limitePret)
    {
        m_idMembre = idMembre;
        m_nom = nom;
        m_telephone = telephone;
        m_limitePret = limitePret;
        m_emprunt = new LinkedList<Livre>();
    }
    
    public long getId()
    {
        return m_id;
    }
    
    public int getIdMembre()
    {
        return m_idMembre;
    }

    public String getNom()
    {
        return m_nom;
    }

    public long getTelephone()
    {
        return m_telephone;
    }

    public int getLimitePret()
    {
        return m_limitePret;
    }
    
    public int getNbPret()
    {
        return m_emprunt.size();
    }
    
    public void ajoutePret(Livre l)
    {
        m_emprunt.add(l);
    }
    
    public void retournerEmprunt(Livre l)
    {
        m_emprunt.remove(l);
    }
}
