package Bibliotheque;

import java.util.List;

import javax.persistence.TypedQuery;

/**
 * Permet d'effectuer les accès à la collection des Membres.
 * 
 * <pre>
 *
 * Vincent Ducharme
 * Université de Sherbrooke
 * Version 1.0 - 18 juin 2016
 * IFT287 - Exploitation de BD relationnelles et OO
 * 
 * Cette classe gère tous les accès à la collection des Membres.
 *
 * </pre>
 */

public class Membres
{
    private TypedQuery<Membre> stmtExiste;
    private Connexion cx;

    /**
     * Creation d'une instance.
     */
    public Membres(Connexion cx)
    {
        this.cx = cx;
        stmtExiste = cx.getConnection().createQuery("select m from Membre m where m.m_idMembre = :idMembre", Membre.class);
    }

    /**
     * Retourner la connexion associée.
     */
    public Connexion getConnexion()
    {
        return cx;
    }

    /**
     * Verifie si un membre existe.
     */
    public boolean existe(int idMembre)
    {
        stmtExiste.setParameter("idMembre", idMembre);
        return !stmtExiste.getResultList().isEmpty();
    }

    /**
     * Lecture d'un membre.
     */
    public Membre getMembre(int idMembre)
    {
        stmtExiste.setParameter("idMembre", idMembre);
        List<Membre> membres = stmtExiste.getResultList();
        if(!membres.isEmpty())
        {
            return membres.get(0);
        }
        else
        {
            return null;
        }
    }

    /**
     * Ajout d'un nouveau membre.
     */
    public Membre inscrire(Membre m)
    {
        cx.getConnection().persist(m);
        return m;
    }

    /**
     * Suppression d'un membre.
     */
    public boolean desinscrire(Membre membre)
    {
        if(membre != null)
        {
            cx.getConnection().remove(membre);
            return true;
        }
        return false;
    }
}
