package Bibliotheque;

import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.TypedQuery;

/**
 * Gestion des transactions d'interrogation dans une bibliothèque.
 * 
 * <pre>
 * 
 *   Vincent Ducharme
 *   Université de Sherbrooke
 *   Version 1.0 - 18 juin 2016
 *   IFT287 - Exploitation de BD relationnelles et OO
 *  
 *   Ce programme permet de faire diverses interrogations
 *   sur l'état de la bibliothèque.
 *  
 *   Pré-condition
 *     La base de données de la bibliothèque doit exister
 *  
 *   Post-condition
 *     Le programme effectue les maj associées à chaque
 *     transaction
 * 
 * 
 * </pre>
 */

public class GestionInterrogation
{
    private TypedQuery<Livre> stmtLivresTitreMot;
    private TypedQuery<Livre> stmtListeTousLivres;
    private Connexion cx;

    /**
     * Creation d'une instance
     */
    public GestionInterrogation(Connexion cx)
    {
        this.cx = cx;

        stmtLivresTitreMot = cx.getConnection().createQuery("select l from Livre l where lower(l.m_titre) like :titre", Livre.class);

        stmtListeTousLivres = cx.getConnection().createQuery("select l from Livre l", Livre.class);
    }

    /**
     * Affiche les livres prêtés depuis plus de 14 jours.
     */
    public void listerLivresRetard(Date date)
    {
        cx.demarreTransaction();
        
        List<Livre> livres = stmtListeTousLivres.getResultList();
        GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        calendar.add(GregorianCalendar.DATE, -14);
        for(Livre l : livres)
        {
            if(l.getEmprunteur() != null)
            {
                if(l.getDatePret().before(calendar.getTime()))
                {
                    System.out.println(l.toString());
                }
            }
        }
        
        cx.commit();
    }

    /**
     * Affiche les livres contenu un mot dans le titre
     */
    public void listerLivresTitre(String mot)
    {
        cx.demarreTransaction();
        
        stmtLivresTitreMot.setParameter("titre", "%" + mot + "%");
        List<Livre> livres = stmtLivresTitreMot.getResultList();

        for(Livre l : livres)
        {
            System.out.println(l.toString());
        }
        
        cx.commit();
    }

    /**
     * Affiche tous les livres de la BD
     */
    public void listerLivres()
    {
        cx.demarreTransaction();
        
        List<Livre> livres = stmtListeTousLivres.getResultList();
                
        for(Livre l : livres)
        {
            System.out.println(l.toString());
        }
        
        cx.commit();
    }
}
