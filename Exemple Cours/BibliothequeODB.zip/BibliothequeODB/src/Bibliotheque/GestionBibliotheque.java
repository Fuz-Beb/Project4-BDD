package Bibliotheque;

/**
 * Système de gestion d'une bibliothèque
 *
 * <pre>
 *
 * Vincent Ducharme
 * Université de Sherbrooke
 * Version 1.0 - 18 juin 2016
 * IFT287 - Exploitation de BD relationnelles et OO
 * 
 * Ce programme permet de gérer les transaction de base d'une
 * bibliothèque.  Il gère des livres, des membres et des
 * réservations. Les données sont conservées dans une base de
 * données objet ObjectDB.
 *
 * Pré-condition
 *   Aucune
 *
 * Post-condition
 *   Le programme effectue les maj associées à chaque
 *   transaction
 * </pre>
 */
public class GestionBibliotheque
{
    private Connexion cx;
    private Livres livres;
    private Membres membres;
    private Reservations reservation;
    private GestionLivre gestionLivre;
    private GestionMembre gestionMembre;
    private GestionPret gestionPret;
    private GestionReservation gestionReservation;

    /**
     * Ouvre une connexion avec la BD objet et alloue les gestionnaires
     * de transactions et de collections.
     * 
     * 
     * @param serveur type du serveur (local ou dinf)
     * @param bd nom de la bade de données
     * @param user user id pour établir une connexion avec la BD
     * @param password mot de passe pour le user id
     */
    public GestionBibliotheque(String serveur, String bd, String user, String password)
            throws BiblioException
    {
        // allocation des objets pour le traitement des transactions
        cx = new Connexion(serveur, bd, user, password);
        livres = new Livres(cx);
        membres = new Membres(cx);
        reservation = new Reservations(cx);
        setGestionLivre(new GestionLivre(livres, reservation));
        setGestionMembre(new GestionMembre(membres, reservation));
        setGestionPret(new GestionPret(livres, membres, reservation));
        setGestionReservation(new GestionReservation(livres, membres, reservation));
    }

    public void fermer()
    {
        // fermeture de la connexion
        cx.fermer();
    }

    public GestionLivre getGestionLivre()
    {
        return gestionLivre;
    }

    private void setGestionLivre(GestionLivre gestionLivre)
    {
        this.gestionLivre = gestionLivre;
    }

    public GestionMembre getGestionMembre()
    {
        return gestionMembre;
    }

    private void setGestionMembre(GestionMembre gestionMembre)
    {
        this.gestionMembre = gestionMembre;
    }

    public GestionPret getGestionPret()
    {
        return gestionPret;
    }

    private void setGestionPret(GestionPret gestionPret)
    {
        this.gestionPret = gestionPret;
    }

    public GestionReservation getGestionReservation()
    {
        return gestionReservation;
    }

    private void setGestionReservation(GestionReservation gestionReservation)
    {
        this.gestionReservation = gestionReservation;
    }
}
